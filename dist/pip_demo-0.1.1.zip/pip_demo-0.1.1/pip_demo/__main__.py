from new_demo.awesome_class import awesome_function
awesome_function()
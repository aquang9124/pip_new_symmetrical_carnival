Functions that you can use!
1. --create
This function will allow you to start your creation of a mysqlconnection file
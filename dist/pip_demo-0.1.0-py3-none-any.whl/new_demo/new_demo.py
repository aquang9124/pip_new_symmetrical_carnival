__version__ ="0.1.0"

import sys
class awesome_class:
    def awesome_function(self):
        print('this is an amazing function')
        print('this is the sys arguments')
        print(sys.argv)
        